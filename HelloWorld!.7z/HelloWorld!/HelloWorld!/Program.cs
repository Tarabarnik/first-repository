﻿/*Hello! This is my first try to show my code to the world
 I will be glad to see any reaction from You on GitHub
 or you can text me: pavelkurilyuk97@gmail.com
 (c) Tarabarnik 
 
  */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace MyCode
{
    class MyCMD
    {
        DirectoryInfo Folder { get; set; }
        List<string> methods;
        public MyCMD(string path)
        {
            Folder = new DirectoryInfo(path);
            methods = new List<string>();
            methods.Add("ATTRIB");
            methods.Add("CD");
            methods.Add("CD..");
            methods.Add("CLS");
            methods.Add("COPY");
            methods.Add("DEL");
            methods.Add("DIR");
            methods.Add("EXIT");
            methods.Add("HELP");
            methods.Add("MKDIR");
            methods.Add("MOVE");
            methods.Add("RD");
            methods.Add("REN");
            methods.Add("TYPE");
            methods.Add("MKTXT");
        }
        void Dir()
        {
            try
            {
                foreach (DirectoryInfo directory in Folder.GetDirectories())
                {
                    Console.WriteLine(directory.Name);
                }
                foreach (FileInfo file in Folder.GetFiles())
                {
                    Console.WriteLine(file.Name);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        void Help()
        {
            Console.WriteLine("ATTRIB Displays file attributes");
            Console.WriteLine("CD     Displays the name of or changes the current directory.");
            Console.WriteLine("CLS    Clears the screen");
            Console.WriteLine("COPY   Copies one or more files or directories to another location.");
            Console.WriteLine("DEL    Deletes one or more files.");
            Console.WriteLine("DIR    Displays a list of files and subdirectories in a directory.");
            Console.WriteLine("HELP   Provides Help information for commands.");
            Console.WriteLine("MKDIR  Creates a directory.");
            Console.WriteLine("MKTXT  Creates new .txt file");
            Console.WriteLine("MOVE   Moves file or directory");
            Console.WriteLine("RD     Deletes directory");
            Console.WriteLine("REN    Renames file or group of files");
            Console.WriteLine("TYPE   Displays content of .txt files");
            Console.WriteLine("EXIT   Close the program");
        }
        void Help(string command)
        {
            try
            {
                using (var fs = new FileStream($"{command}.txt", FileMode.Open))
                {
                    using (var fr = new StreamReader(fs, Encoding.Default))
                    {
                        Console.WriteLine(fr.ReadToEnd());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void Cd()
        {
            Console.WriteLine(Folder.FullName);
        }
        void Cd2()
        {
            if (Folder.Parent != null)
            {
                Folder = Folder.Parent;
                Console.WriteLine(Folder.FullName);
            }
            else
                Console.WriteLine(Folder.FullName);
        }
        void Cd3(string path)
        {
            DirectoryInfo pathDir = new DirectoryInfo(path);
            if (pathDir.Root != Folder.Root)
            {
                Folder = pathDir;
                return;
            }
            foreach (DirectoryInfo dir in Folder.GetDirectories())
            {

                if (dir.Name.ToLower() == path.ToLower())
                {
                    Folder = dir;
                    return;
                }
            }
            Console.WriteLine("The system cannot find the path specified.");
        }
        void Cls()
        {
            Console.Clear();
        }
        void Del(string[] arr)
        {
            try
            {
                foreach (string str in arr)
                {
                    FileInfo dir = new FileInfo(Folder.FullName + '/' + str);
                    if (dir.Exists)
                        dir.Delete();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void MkDir(string name)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(name);
                if (!dir.Exists)
                    dir.Create();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void MoveFolder(string f1, string f2)
        {

            if (Directory.Exists(f1) && Directory.Exists(f2))
            {
                DirectoryInfo dir1 = new DirectoryInfo(f1);
                dir1.MoveTo(f2 + '/' + dir1.Name);
            }
        }
        void CopyFolder(string[] arr)
        {
            for (int i = 0; i < arr.Length - 1; ++i)
            {
                DirectoryInfo di = new DirectoryInfo(arr[i]);
                if (Directory.Exists(arr[i++]) && Directory.Exists(arr[i]) == false)
                {
                    DirectoryInfo dir = new DirectoryInfo(arr[i]);
                    dir.Create();
                }
            }
        }
        void CopyFile(string[] arr)
        {
            for (int i = 0; i < arr.Length - 1; ++i)
            {
                FileInfo fi = new FileInfo(arr[i++]);
                if (fi.Exists)
                {
                    fi.CopyTo(arr[i], true);
                }
            }
        }
        void MoveFile(string f1, string f2)
        {
            if (File.Exists(f1) && File.Exists(f2) == false)
            {
                FileInfo fi1 = new FileInfo(f1);
                fi1.MoveTo(f2);
            }
        }
        void ReadTextFile(string file)
        {
            try
            {
                if (File.Exists(file) && file.EndsWith(".txt"))
                {
                    using (FileStream fs = new FileStream(file, FileMode.Open))
                    {
                        using (var sr = new StreamReader(fs, Encoding.Default))
                        {
                            Console.WriteLine(sr.ReadToEnd());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void MkTxtFile(string name)
        {
            try
            {
                FileInfo fi = new FileInfo(name);
                if (fi.Exists)
                    fi.Delete();
                fi.Create();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void Attrib(string file)
        {
            try
            {
                FileInfo fi = new FileInfo(file);
                Console.WriteLine(fi.Attributes);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void Ren(string[] arr)
        {
            try
            {
                for (int i = 0; i < arr.Length - 1; ++i)
                {
                    FileInfo fi1 = new FileInfo(arr[i++]);
                    FileInfo fi2 = new FileInfo(fi1.DirectoryName + '/' + arr[i]);
                    if (fi1.Exists)
                    {
                        fi1.CopyTo(fi2.FullName, true);
                        fi1.Delete();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        void RD(string path)
        {
            DirectoryInfo dir = new DirectoryInfo(path);
            if (dir.Exists)
            {
                foreach (var file in dir.GetFiles())
                {
                    file.Delete();
                }
                foreach (var d in dir.GetDirectories())
                {
                    RD(d.FullName);
                }
                dir.Delete();
            }
        }
        public void HandleInput()
        {
            while (true)
            {
                Console.Write($"{Folder.FullName}>");
                string input = Console.ReadLine();
                string[] arr = input.Split();
                arr[0] = arr[0].ToUpper();
                if (methods.Contains(arr[0]))
                {
                    switch (arr[0])
                    {
                        case "CD":
                            {
                                if (arr.Length == 1)
                                    Cd();
                                else if (arr.Length == 2)
                                    Cd3(arr[1]);
                                else Console.WriteLine("System can not file this directory");
                            }
                            break;
                        case "CD..":
                            Cd2();
                            break;
                        case "CLS":
                            Cls();
                            break;
                        case "COPY":
                            {
                                arr[1] = arr[1].ToLower();
                                if (arr[1] == "/f")
                                {
                                    if (arr.Length >= 4 && arr.Length % 2 == 0)
                                    {
                                        string[] files = new string[arr.Length - 2];
                                        for (int i = 2; i < arr.Length; ++i)
                                        {
                                            files[i - 2] = arr[i];
                                        }
                                        CopyFile(files);
                                    }
                                }
                                else if (arr[1] == "/d")
                                {
                                    if (arr.Length >= 4 && arr.Length % 2 == 0)
                                    {
                                        string[] dirs = new string[arr.Length - 2];
                                        for (int i = 2; i < arr.Length; ++i)
                                        {
                                            dirs[i - 2] = arr[i];
                                        }
                                        CopyFolder(dirs);
                                    }
                                }
                                else
                                    Console.WriteLine("Wrong input");
                            }
                            break;
                        case "DEL":
                            {
                                string[] files = new string[arr.Length - 1];
                                for (int i = 1; i < arr.Length; ++i)
                                {
                                    files[i - 1] = arr[i];
                                }
                                Del(files);
                            }
                            break;
                        case "DIR":
                            Dir();
                            break;
                        case "HELP":
                            {
                                if (arr.Length == 1)
                                    Help();
                                else
                                {
                                    Help(arr[1].ToLower());
                                }
                            }
                            break;
                        case "MKDIR":
                            MkDir(arr[1]);
                            break;
                        case "MOVE":
                            {
                                if (arr.Length == 4)
                                {
                                    arr[1] = arr[1].ToLower();
                                    if (arr[1] == "/f")
                                    {
                                        MoveFile(arr[2], arr[3]);
                                    }
                                    else if (arr[1] == "/d")
                                    {
                                        MoveFolder(arr[2], arr[3]);
                                    }
                                }
                            }
                            break;
                        case "ATTRIB":
                            Attrib(arr[1]);
                            break;
                        case "RD":
                            RD(arr[1]);
                            break;
                        case "REN":
                            {
                                string[] files = new string[arr.Length - 1];
                                for (int i = 1; i < arr.Length; ++i)
                                {
                                    files[i - 1] = arr[i];
                                }
                                Ren(files);
                            }
                            break;
                        case "TYPE":
                            ReadTextFile(arr[1]);
                            break;
                        case "MKTXT":
                            MkTxtFile(arr[1]);
                            break;
                        case "EXIT":
                            return;
                        default:
                            Console.WriteLine("Wrong input");
                            break;
                    }
                }
                else
                    Console.WriteLine("Wrong input");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to my \"tinyCD\"!");
            Console.WriteLine("Please, enter any directory on your PC, and we'll start!");
            string path = Console.ReadLine();
            MyCMD m = new MyCMD(@path);
            m.HandleInput();
        }
    }
}